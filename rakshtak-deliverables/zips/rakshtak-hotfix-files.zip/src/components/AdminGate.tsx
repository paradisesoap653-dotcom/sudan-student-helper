"use client";

import { useEffect, useState, type ReactNode, type FormEvent } from "react";

/** مفتاح التخزين المحلي لرمز الإدارة */
export const ADMIN_TOKEN_KEY = "rakshtak_admin_token";

export function getAdminToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage.getItem(ADMIN_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setAdminToken(token: string): void {
  try {
    window.sessionStorage.setItem(ADMIN_TOKEN_KEY, token.trim());
  } catch {
    /* التخزين غير متاح */
  }
}

export function clearAdminToken(): void {
  try {
    window.sessionStorage.removeItem(ADMIN_TOKEN_KEY);
  } catch {
    /* تجاهل */
  }
}

/**
 * بوابة إدارية لصفحتَي /admin و /dashboard:
 * تطلب رمز RAKSHTAK_ADMIN_TOKEN قبل عرض أي محتوى، وتخزّنه في sessionStorage
 * (يختفي بمجرد إغلاق التبويب). المسارات الخادمية تتحقق من الرمز نفسها
 * وترجع 403 لأي طلب بدون x-admin-token صحيح.
 */
export default function AdminGate({
  children,
  title = "بوابة الإدارة",
}: {
  children: ReactNode;
  title?: string;
}) {
  const [token, setToken] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setToken(getAdminToken());
    setReady(true);
  }, []);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const value = input.trim();
    if (!value) return;
    setAdminToken(value);
    setToken(value);
  };

  // تجنّب وميض أثناء التحميل (لا نقرأ sessionStorage في أول render للخادم)
  if (!ready) {
    return (
      <div className="min-h-screen bg-[#0d1117] flex items-center justify-center">
        <div className="text-slate-500 text-sm">جاري التحميل...</div>
      </div>
    );
  }

  if (token) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-[#0d1117] text-slate-100 flex items-center justify-center p-4">
      <form
        onSubmit={submit}
        className="w-full max-w-sm bg-[#161b22] border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl"
      >
        <div className="text-center space-y-1.5">
          <div className="text-4xl">🔐</div>
          <h1 className="text-lg font-extrabold text-white">{title}</h1>
          <p className="text-xs text-slate-400 leading-relaxed">
            هذه الصفحة إدارية ومقفولة. أدخل رمز الإدارة
            (RAKSHTAK_ADMIN_TOKEN) للمتابعة.
          </p>
        </div>

        <input
          type="password"
          autoFocus
          required
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="رمز الإدارة"
          className="w-full bg-[#0d1117] border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono text-left"
          dir="ltr"
        />

        <button
          type="submit"
          className="w-full py-3 bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-slate-950 font-extrabold rounded-xl text-sm shadow-lg transition"
        >
          دخول الإدارة 🚀
        </button>

        <p className="text-[10px] text-slate-500 text-center leading-relaxed">
          بدون ضبط RAKSHTAK_ADMIN_TOKEN على الخادم تبقى كل مسارات /api
          الإدارية مقفولة (403) — هذا هو الوضع الآمن المتعمّد.
        </p>
      </form>
    </div>
  );
}
