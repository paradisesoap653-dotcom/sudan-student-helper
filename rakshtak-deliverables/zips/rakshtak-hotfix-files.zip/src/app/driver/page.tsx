"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Map from "@/components/Map";
import { supabase } from "@/lib/supabase";
import { normalizeSudanesePhone, formatPrice, maskAccount } from "@/lib/format";

interface Ride {
  id: string | number;
  passenger_name: string;
  phone_number: string;
  pickup_location: string;
  destination: string;
  offered_price: number | null;
  service_type: string;
  status: "pending" | "accepted" | "completed" | "cancelled";
  driver_phone?: string;
}

/** مقارنة معرّفات متسامحة (رقم/نص) */
const sameId = (a: string | number | undefined, b: string | number | undefined) =>
  a !== undefined && b !== undefined && String(a) === String(b);

export default function DriverDashboard() {
  const [phoneDigits, setPhoneDigits] = useState(""); // أرقام محلية فقط أثناء الكتابة
  const [bankAccount, setBankAccount] = useState("");
  const [showBank, setShowBank] = useState(false);
  const [isDriverLoggedIn, setIsDriverLoggedIn] = useState(false);

  const [isAvailable, setIsAvailable] = useState(true);
  const [availableRides, setAvailableRides] = useState<Ride[]>([]);
  const [currentRide, setCurrentRide] = useState<Ride | null>(null);
  const [activeTab, setActiveTab] = useState<"available" | "current">("available");

  // refs لتفادي إعادة الاشتراك المتكرر في realtime
  const driverPhoneRef = useRef("");
  const currentRideRef = useRef<Ride | null>(null);
  const isAvailableRef = useRef(true);
  const acceptingRef = useRef(false);
  const prevAvailableCountRef = useRef(0);
  const audioCtxRef = useRef<AudioContext | null>(null);

  /** مزامنة currentRide بين الحالة و ref */
  const syncCurrentRide = useCallback((ride: Ride | null) => {
    currentRideRef.current = ride;
    setCurrentRide(ride);
  }, []);

  const driverFullPhone = normalizeSudanesePhone(phoneDigits) ?? "";

  // استرجاع الجلسة المحفوظة
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedPhone = localStorage.getItem("driver_phone");
      const savedBank = localStorage.getItem("driver_bank");
      if (savedPhone) {
        const normalized = normalizeSudanesePhone(savedPhone);
        if (normalized) {
          setPhoneDigits(normalized.replace("+249", ""));
          driverPhoneRef.current = normalized;
          setIsDriverLoggedIn(true);
        }
      }
      if (savedBank) setBankAccount(savedBank);
    }
  }, []);

  // 1. طلب إذن الإشعارات بأمان
  useEffect(() => {
    if (isDriverLoggedIn && typeof window !== "undefined" && "Notification" in window) {
      Notification.requestPermission().catch(() => {});
    }
  }, [isDriverLoggedIn]);

  /**
   * 2. تنبيه WebAudio داخلي بالكامل (بدون أي ملف صوتي خارجي):
   *    نغمتان قصيرتان تولَّدان داخل المتصفح — تعمل حتى بدون إنترنت
   */
  const playNewRideSound = useCallback(() => {
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      if (!audioCtxRef.current) audioCtxRef.current = new Ctx();
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") void ctx.resume();

      const now = ctx.currentTime;
      [880, 1174.66].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        const start = now + i * 0.18;
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.22, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.16);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + 0.2);
      });
    } catch (err) {
      console.log("Audio notification error:", err);
    }
  }, []);

  // التنبيه عند وصول طلب جديد فعلياً (وليس عند كل إعادة رسم)
  useEffect(() => {
    if (!isDriverLoggedIn) return;
    const count = availableRides.length;
    if (count > prevAvailableCountRef.current && count > 0 && !currentRideRef.current) {
      playNewRideSound();
      if ("Notification" in window && Notification.permission === "granted") {
        const latest = availableRides[0];
        if (latest) {
          try {
            new Notification("طلب مشوار جديد! 🛺", {
              body: `من: ${latest.pickup_location || "الموقع"} - إلى: ${latest.destination || "الوجهة"}`,
              icon: "/icon.png",
            });
          } catch {
            /* بعض المتصفحات تمنع الإنشاء من SW قديم */
          }
        }
      }
    }
    prevAvailableCountRef.current = count;
  }, [availableRides.length, isDriverLoggedIn, playNewRideSound]);

  const handleDriverLogin = (e: React.FormEvent) => {
    e.preventDefault();

    const fullPhone = normalizeSudanesePhone(phoneDigits);
    if (!fullPhone) {
      alert("الرجاء إدخال رقم هاتف سوداني صحيح (9 أرقام تبدأ بـ 9)");
      return;
    }

    const cleanBank = bankAccount.trim().replace(/\s+/g, "");
    if (cleanBank.length < 6) {
      alert("الرجاء إدخال رقم حساب بنكي صحيح (6 أرقام على الأقل) لتحويل المستحقات");
      return;
    }

    localStorage.setItem("driver_phone", fullPhone);
    localStorage.setItem("driver_bank", cleanBank);
    driverPhoneRef.current = fullPhone;
    setPhoneDigits(fullPhone.replace("+249", ""));
    setBankAccount(cleanBank);
    setIsDriverLoggedIn(true);
  };

  const handleDriverLogout = () => {
    localStorage.removeItem("driver_phone");
    localStorage.removeItem("driver_bank");
    driverPhoneRef.current = "";
    currentRideRef.current = null;
    setIsDriverLoggedIn(false);
    setPhoneDigits("");
    setBankAccount("");
    setShowBank(false);
    setCurrentRide(null);
    setAvailableRides([]);
    setActiveTab("available");
  };

  // 3. اشتراك واحد فقط في realtime طول فترة تسجيل الدخول (لا يتكرر مع كل تحديث)
  useEffect(() => {
    if (!isDriverLoggedIn) return;

    const fetchRides = async () => {
      const { data, error } = await supabase
        .from("rides")
        .select("*")
        .order("created_at", { ascending: false });

      // استبعاد المشاوير الملغاة من القائمة
      const visible = (data || []).filter(
        (r: any) => r.status !== "cancelled"
      );

      if (!error && visible) {
        const pending = visible.filter((r: any) => r.status === "pending");
        // «مشواري أنا» فقط: الرحلة المقبولة تظهر كـ"حالية" لو كانت driver_phone فيها = رقمي
        const myAccepted = visible.find(
          (r: any) =>
            r.status === "accepted" && r.driver_phone === driverPhoneRef.current
        );
        setAvailableRides(pending);
        if (myAccepted && !currentRideRef.current) {
          syncCurrentRide(myAccepted);
        }
      }
    };

    void fetchRides();

    const channel = supabase
      .channel("driver-rides-channel")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "rides" },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const newRide = payload.new as Ride;
            if (newRide.status === "pending") {
              setAvailableRides((prev) =>
                prev.some((r) => sameId(r.id, newRide.id))
                  ? prev
                  : [newRide, ...prev]
              );
            }
            return;
          }

          if (payload.eventType !== "UPDATE") return;
          const upd = payload.new as Ride;

          if (upd.status === "cancelled") {
            // الطلب اتلغى: شيله من القايمة، ولو كان مشواري الحالي بلّغ
            setAvailableRides((prev) => prev.filter((r) => !sameId(r.id, upd.id)));
            if (currentRideRef.current && sameId(currentRideRef.current.id, upd.id)) {
              alert("تم إلغاء المشوار ده من الراكب");
              syncCurrentRide(null);
              setActiveTab("available");
            }
            return;
          }

          if (upd.status === "pending") {
            setAvailableRides((prev) => {
              const exists = prev.some((r) => sameId(r.id, upd.id));
              return exists
                ? prev.map((r) => (sameId(r.id, upd.id) ? upd : r))
                : [upd, ...prev];
            });
            return;
          }

          if (upd.status === "accepted") {
            // أي سائق قبله؟ خلاص يخرج من قائمة المتاح
            setAvailableRides((prev) => prev.filter((r) => !sameId(r.id, upd.id)));

            // «مشواري أنا» فقط: لو القبول ده لرقمي ولسه مفيش مشوار حالي → خلّيه حالي
            if (
              upd.driver_phone === driverPhoneRef.current &&
              !currentRideRef.current
            ) {
              syncCurrentRide(upd);
            }
            return;
          }

          if (upd.status === "completed") {
            if (currentRideRef.current && sameId(currentRideRef.current.id, upd.id)) {
              alert("تم إنهاء المشوار 🏁");
              syncCurrentRide(null);
              setActiveTab("available");
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // الاشتراك يُنشأ مرة واحدة عند الدخول فقط
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isDriverLoggedIn]);

  const acceptRide = async (ride: Ride) => {
    // قفل القبول المزدوج: لا قبول جديد أثناء مشوار حالي أو أثناء طلب قيد التنفيذ
    if (acceptingRef.current) return;
    if (currentRideRef.current) {
      alert("عندك مشوار حالي — أنهيه أولاً قبل ما تقبل طلب جديد");
      return;
    }
    if (!isAvailableRef.current) {
      alert("فعّل «متاح للطلبات 🟢» أولاً عشان تقدر تقبل مشاوير");
      return;
    }

    acceptingRef.current = true;
    try {
      // تحديث شرطي: ما يتقبلش إلا لو لسه pending — يمنع سباق سائقين على نفس الطلب
      const { data, error } = await supabase
        .from("rides")
        .update({ status: "accepted", driver_phone: driverFullPhone })
        .eq("id", ride.id)
        .eq("status", "pending")
        .select()
        .maybeSingle();

      if (error || !data) {
        setAvailableRides((prev) => prev.filter((r) => !sameId(r.id, ride.id)));
        alert("الطلب ده اتقبل من سائق تاني قبل ما تدوس — جرب طلب تاني");
        return;
      }

      syncCurrentRide(data as Ride);
      setActiveTab("current");
    } finally {
      acceptingRef.current = false;
    }
  };

  const completeRide = async (rideId: string | number) => {
    if (acceptingRef.current) return;

    const { error } = await supabase
      .from("rides")
      .update({ status: "completed" })
      .eq("id", rideId)
      .eq("status", "accepted"); // شرط: تُكمل الرحلة الحالية فقط

    if (error) {
      alert("خطأ أثناء إنهاء المشوار: " + error.message);
    } else {
      syncCurrentRide(null);
      setActiveTab("available");
      prevAvailableCountRef.current = 0;
    }
  };

  const toggleAvailability = () => {
    const next = !isAvailable;
    isAvailableRef.current = next;
    setIsAvailable(next);
  };

  const maskedBank = maskAccount(bankAccount);

  return (
    <div className="min-h-screen bg-[#161b22] text-slate-100 p-4 flex flex-col justify-between w-full min-w-full">
      <div className="w-full max-w-xl mx-auto flex-1 flex flex-col justify-between space-y-4">
        {/* الشريط العلوي */}
        <header className="flex justify-between items-center pt-2 pb-1">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🚖</span>
            <span className="font-extrabold text-xl text-white tracking-wide">لوحة السائق</span>
          </div>

          <button
            type="button"
            onClick={() => { window.location.href = "/"; }}
            className="bg-amber-500/10 hover:bg-amber-500/20 active:scale-95 text-amber-400 font-bold text-sm px-4 py-2.5 rounded-xl border border-amber-500/30 transition flex items-center gap-2 shadow-lg"
          >
            <span>🛺</span> الرئيسية (الراكب)
          </button>
        </header>

        {!isDriverLoggedIn ? (
          <form onSubmit={handleDriverLogin} className="space-y-5 py-8 flex-1 flex flex-col justify-center">
            <div className="text-center space-y-1.5">
              <h2 className="text-lg font-bold text-white">تسجيل دخول السائق 🚖</h2>
              <p className="text-xs text-slate-400">أدخل رقم هاتفك وحسابك البنكي للمتابعة</p>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1.5 block text-right">📞 رقم الهاتف:</label>

              <div
                className="flex items-stretch border border-slate-700 rounded-xl overflow-hidden bg-[#0d1117] focus-within:border-amber-500"
                style={{ direction: 'ltr' }}
              >
                <div className="bg-slate-800 text-amber-400 px-3.5 py-3 text-sm font-mono font-bold border-r border-slate-700 flex items-center gap-1.5 select-none shrink-0">
                  <span>🇸🇩</span>
                  <span style={{ direction: 'ltr', unicodeBidi: 'isolate' }}>+249</span>
                </div>

                <input
                  type="tel"
                  required
                  inputMode="numeric"
                  maxLength={10}
                  value={phoneDigits}
                  onChange={(e) => setPhoneDigits(e.target.value.replace(/\D/g, "").slice(0, 10))}
                  placeholder="9XXXXXXXX"
                  className="w-full bg-transparent px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none font-mono text-left"
                  style={{ direction: 'ltr' }}
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 mb-1.5 block text-right">🏦 رقم الحساب البنكي (بنكك/صكوك):</label>
              <div className="relative">
                <input
                  type={showBank ? "text" : "password"}
                  required
                  value={bankAccount}
                  onChange={(e) => setBankAccount(e.target.value.replace(/\s+/g, ""))}
                  placeholder="أدخل رقم الحساب البنكي"
                  className="w-full bg-[#0d1117] border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none font-mono text-right focus:border-amber-500 pl-14"
                />
                <button
                  type="button"
                  onClick={() => setShowBank((s) => !s)}
                  tabIndex={-1}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1.5 rounded-lg border border-slate-700 transition"
                >
                  {showBank ? "إخفاء 🙈" : "إظهار 👁️"}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-slate-950 font-extrabold rounded-2xl text-base shadow-xl transition mt-2"
            >
              دخول لوحة السائق 🚀
            </button>
          </form>
        ) : (
          <>
            {/* شريط معلومات السائق — الحساب البنكي مقنّع */}
            <div className="flex items-center justify-between bg-[#0d1117] p-3 rounded-2xl border border-slate-800">
              <div className="text-xs text-slate-300 space-y-1">
                <div>📞 هاتف: <span className="font-mono text-amber-400 font-bold" style={{ direction: "ltr", display: "inline-block" }}>+249{phoneDigits}</span></div>
                <div className="flex items-center gap-1.5">
                  <span>🏦 الحساب:</span>
                  <span className="font-mono text-amber-400 font-bold" dir="ltr">
                    {maskedBank || "—"}
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowBank((s) => !s)}
                    className="text-[9px] bg-slate-800 hover:bg-slate-700 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 transition"
                  >
                    {showBank ? "إخفاء" : "إظهار"}
                  </button>
                </div>
                {showBank && bankAccount && (
                  <div className="text-[10px] text-slate-500">
                    الرقم الكامل: <span className="font-mono text-slate-300">{bankAccount}</span>
                  </div>
                )}
              </div>
              <button
                onClick={handleDriverLogout}
                className="text-xs font-bold text-red-400 hover:text-red-300 bg-red-500/10 px-3 py-2 rounded-xl border border-red-500/20 transition"
              >
                تغيير البيانات
              </button>
            </div>

            {/* حالة التواجد */}
            <div className="flex justify-between items-center bg-[#0d1117] p-3 rounded-2xl border border-slate-800">
              <span className="text-sm font-semibold text-slate-300">حالة التواجد:</span>
              <button
                onClick={toggleAvailability}
                className={`text-xs px-4 py-2 rounded-xl font-extrabold transition flex items-center gap-2 ${
                  isAvailable
                    ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                    : "bg-red-500/10 text-red-400 border border-red-500/30"
                }`}
              >
                <span className={`w-2.5 h-2.5 rounded-full ${isAvailable ? "bg-emerald-400" : "bg-red-400"}`}></span>
                {isAvailable ? "متاح للطلبات 🟢" : "مشغول / استراحة 🔴"}
              </button>
            </div>

            {/* الخريطة */}
            <div className="w-full h-48 rounded-2xl overflow-hidden border border-slate-700/60 shadow-xl shrink-0">
              <Map pickupName={currentRide ? currentRide.pickup_location : "موقعي الحالي"} />
            </div>

            {/* تبويب الطلبات والمشوار الحالي */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setActiveTab("available")}
                className={`py-3 text-xs font-extrabold rounded-xl border transition ${
                  activeTab === "available"
                    ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md"
                    : "bg-[#0d1117] text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                الطلبات المتاحة 🔔 ({availableRides.length})
              </button>
              <button
                onClick={() => setActiveTab("current")}
                className={`py-3 text-xs font-extrabold rounded-xl border transition ${
                  activeTab === "current"
                    ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md"
                    : "bg-[#0d1117] text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                المشوار الحالي 🚖 {currentRide ? "(1)" : "(0)"}
              </button>
            </div>

            {/* المحتوى */}
            {activeTab === "available" ? (
              <div className="space-y-3 flex-1">
                {!isAvailable ? (
                  <div className="text-center py-10 bg-[#0d1117] border border-slate-800 rounded-2xl text-slate-500 text-xs font-medium">
                    أنت في وضع «مشغول / استراحة 🔴» — الطلبات الجديدة لن تُقبل منك.
                  </div>
                ) : availableRides.length === 0 ? (
                  <div className="text-center py-10 bg-[#0d1117] border border-slate-800 rounded-2xl text-slate-500 text-xs font-medium">
                    لا توجد طلبات متاحة حالياً. انتظر قليلاً... ⏳
                  </div>
                ) : (
                  availableRides.map((ride) => (
                    <div key={ride.id} className="bg-[#0d1117] border border-slate-700/80 rounded-2xl p-4 space-y-3 shadow-lg">
                      <div className="flex justify-between items-center text-xs border-b border-slate-800 pb-2.5">
                        <span className="font-bold text-white text-sm">👤 {ride.passenger_name}</span>
                        <span className="bg-amber-500/10 text-amber-400 px-2.5 py-1 rounded-lg border border-amber-500/20 font-bold">
                          {ride.service_type || "ركشة ركاب"}
                        </span>
                      </div>
                      <div className="text-xs space-y-1.5 text-slate-300">
                        <div>📍 من: <span className="text-white font-semibold">{ride.pickup_location}</span></div>
                        <div>🏁 إلى: <span className="text-white font-semibold">{ride.destination}</span></div>
                        {ride.offered_price ? (
                          <div className="text-amber-400 font-bold font-mono text-sm">
                            💰 السعر المقترح: <span style={{ direction: "ltr", display: "inline-block" }}>{formatPrice(ride.offered_price)} ج.س</span>
                          </div>
                        ) : null}
                        <div className="text-slate-400 flex items-center justify-between pt-1">
                          <span>📞 الهاتف:</span>
                          <a
                            href={`tel:${ride.phone_number}`}
                            className="font-mono text-amber-400 hover:underline font-bold text-sm"
                            style={{ direction: "ltr" }}
                          >
                            {ride.phone_number}
                          </a>
                        </div>
                      </div>
                      <button
                        onClick={() => acceptRide(ride)}
                        disabled={!!currentRide || acceptingRef.current}
                        className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg transition disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        {currentRide ? "عندك مشوار حالي أولاً" : "قبول المشوار ✅"}
                      </button>
                    </div>
                  ))
                )}
              </div>
            ) : (
              <div className="space-y-3 flex-1">
                {!currentRide ? (
                  <div className="text-center py-10 bg-[#0d1117] border border-slate-800 rounded-2xl text-slate-500 text-xs font-medium">
                    لا توجد رحلة حالية قيد التنفيذ.
                  </div>
                ) : (
                  <div className="bg-[#0d1117] border border-slate-700/80 rounded-2xl p-4 space-y-3.5 shadow-lg">
                    <div className="flex justify-between items-center text-xs border-b border-slate-800 pb-2.5">
                      <span className="font-bold text-emerald-400 text-sm">🟢 مشوار جاري (مشواري أنا)</span>
                      <span className="font-bold text-white text-sm">👤 {currentRide.passenger_name}</span>
                    </div>
                    <div className="text-xs space-y-1.5 text-slate-300">
                      <div>📍 من: <span className="text-white font-semibold">{currentRide.pickup_location}</span></div>
                      <div>🏁 إلى: <span className="text-white font-semibold">{currentRide.destination}</span></div>
                      {currentRide.offered_price ? (
                        <div className="text-amber-400 font-bold font-mono text-sm">
                          💰 السعر المقترح: <span style={{ direction: "ltr", display: "inline-block" }}>{formatPrice(currentRide.offered_price)} ج.س</span>
                        </div>
                      ) : null}
                      <div className="text-slate-400 flex items-center justify-between pt-1">
                        <span>📞 الهاتف:</span>
                        <a
                          href={`tel:${currentRide.phone_number}`}
                          className="font-mono text-amber-400 hover:underline font-bold text-sm"
                          style={{ direction: "ltr" }}
                        >
                          {currentRide.phone_number}
                        </a>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <a
                        href={`tel:${currentRide.phone_number}`}
                        className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-center text-xs font-bold rounded-xl border border-slate-700 transition"
                      >
                        اتصال بالزبون 📞
                      </a>
                      <a
                        href={`https://wa.me/${currentRide.phone_number.replace("+", "")}`}
                        target="_blank"
                        rel="noreferrer"
                        className="py-2.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 text-center text-xs font-bold rounded-xl border border-emerald-500/30 transition"
                      >
                        واتساب 💬
                      </a>
                    </div>

                    <button
                      onClick={() => completeRide(currentRide.id)}
                      disabled={acceptingRef.current}
                      className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg transition disabled:opacity-50"
                    >
                      إكمال / إنهاء المشوار 🏁
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
