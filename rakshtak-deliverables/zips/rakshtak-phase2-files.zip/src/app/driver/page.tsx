"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Map from "@/components/Map";
import { supabase } from "@/lib/supabase";
import { normalizeSudanesePhone, formatPrice, maskAccount } from "@/lib/format";
import { serviceTypeLabel } from "@/lib/constants";
import {
  haversineKm,
  radiusBounds,
  formatKm,
  DEFAULT_SEARCH_RADIUS_KM,
} from "@/lib/geo";

/* ════════════════════════════════════════════════════════════════════
 *  لوحة السائق — المرحلة 2:
 *  • دخول حقيقي برمز OTP (مسارات خادم + جدول drivers على Supabase)
 *  • هوية السائق driver_id (integer FK) تُكتب على الرحلة عند القبول
 *  • «مشواري أنا» فقط: المطابقة عبر driver_id (مع دعم driver_phone القديم)
 *  • فلتر «الأقرب»: pickup_lat/lng + موقع السائق (نصف قطر 10 كم)
 *  • قبول شرطي يمنع القبول المزدوج + اشتراك realtime واحد + WebAudio داخلي
 *  • قناع الحساب البنكي
 * ════════════════════════════════════════════════════════════════════ */

interface Ride {
  id: string | number;
  passenger_name: string;
  phone_number: string;
  pickup_location: string;
  destination: string;
  offered_price: number | null;
  service_type: string;
  status: "pending" | "accepted" | "completed" | "cancelled";
  driver_id?: number | null;
  driver_phone?: string | null;
  pickup_lat?: number | null;
  pickup_lng?: number | null;
  distanceKm?: number | null; // تُحسب محلياً لعرض «الأقرب»
}

interface DriverProfile {
  id: number;
  phone: string;
  name: string;
  bankAccount: string | null;
  vehicleType: string | null;
  isOnline: boolean;
}

const sameId = (a: unknown, b: unknown) =>
  a !== undefined && a !== null && b !== undefined && b !== null && String(a) === String(b);

type AuthStage = "login" | "code" | "ready";

export default function DriverDashboard() {
  // ── حالة المصادقة ─────────────────────────────────────────────
  const [stage, setStage] = useState<AuthStage>("login");
  const [phoneDigits, setPhoneDigits] = useState("");
  const [codeDigits, setCodeDigits] = useState("");
  const [busy, setBusy] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authInfo, setAuthInfo] = useState<string | null>(null);
  const [previewCode, setPreviewCode] = useState<string | null>(null);
  const [profile, setProfile] = useState<DriverProfile | null>(null);
  const [editingProfile, setEditingProfile] = useState(false);
  const [nameDraft, setNameDraft] = useState("");
  const [bankDraft, setBankDraft] = useState("");
  const [vehicleDraft, setVehicleDraft] = useState("");
  const [showBank, setShowBank] = useState(false);

  // ── حالة العمل ────────────────────────────────────────────────
  const [isAvailable, setIsAvailable] = useState(true);
  const [availableRides, setAvailableRides] = useState<Ride[]>([]);
  const [currentRide, setCurrentRide] = useState<Ride | null>(null);
  const [activeTab, setActiveTab] = useState<"available" | "current">("available");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [geoMsg, setGeoMsg] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);

  // ── refs ──────────────────────────────────────────────────────
  const profileRef = useRef<DriverProfile | null>(null);
  const currentRideRef = useRef<Ride | null>(null);
  const acceptingRef = useRef(false);
  const prevCountRef = useRef(0);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const coordsRef = useRef<{ lat: number; lng: number } | null>(null);

  const syncProfile = useCallback((p: DriverProfile | null) => {
    profileRef.current = p;
    setProfile(p);
  }, []);

  const syncCurrentRide = useCallback((ride: Ride | null) => {
    currentRideRef.current = ride;
    setCurrentRide(ride);
  }, []);

  const fullPhone = normalizeSudanesePhone(phoneDigits);

  /** هل الرحلة «مشواري أنا»؟ المطابقة الأساسية driver_id ثم driver_phone للقديم */
  const isMine = useCallback(
    (ride: { driver_id?: number | null; driver_phone?: string | null }): boolean => {
      const p = profileRef.current;
      if (!p) return false;
      if (ride.driver_id !== undefined && ride.driver_id !== null) {
        return sameId(ride.driver_id, p.id);
      }
      return (ride.driver_phone || "") === p.phone;
    },
    []
  );

  // ── 0) استعادة الجلسة عند فتح الصفحة ─────────────────────────
  useEffect(() => {
    if (typeof window === "undefined") return;

    const token = localStorage.getItem("driver_token");
    const legacyPhone = localStorage.getItem("driver_phone");
    if (legacyPhone && !token) {
      // هجرة من الإصدار القديم: نملأ الرقم ونطلب التحقق بالرمز
      const norm = normalizeSudanesePhone(legacyPhone);
      if (norm) setPhoneDigits(norm.replace("+249", ""));
    }

    if (!token) return;

    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/driver/me", {
          headers: { "x-driver-token": token },
        });
        const data = await res.json().catch(() => ({}));
        if (cancelled) return;
        if (res.ok && data.ok && data.driver) {
          const p: DriverProfile = {
            id: Number(data.driver.id),
            phone: data.driver.phone,
            name: data.driver.name || "",
            bankAccount: data.driver.bankAccount || null,
            vehicleType: data.driver.vehicleType || null,
            isOnline: data.driver.isOnline !== false,
          };
          syncProfile(p);
          setPhoneDigits(p.phone.replace("+249", ""));
          setIsAvailable(p.isOnline);
          setStage("ready");
          locateDriver();
          return;
        }
        localStorage.removeItem("driver_token");
        localStorage.removeItem("driver_id");
        setAuthError("انتهت جلستك — سجّل الدخول برمز التحقق من جديد");
      } catch {
        if (!cancelled) {
          setAuthError("تعذر الاتصال بالخادم — تأكد من تشغيل المتغيرات ثم أعد المحاولة");
        }
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── تنبيه WebAudio داخلي عند وصول طلب جديد ────────────────────
  const playAlert = useCallback(() => {
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      if (!audioCtxRef.current) audioCtxRef.current = new Ctx();
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") void ctx.resume();
      const now = ctx.currentTime;
      [880, 1174.66].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        const start = now + i * 0.18;
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.22, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.16);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + 0.2);
      });
    } catch (err) {
      console.log("Audio notification error:", err);
    }
  }, []);

  useEffect(() => {
    if (!profile) return;
    const count = availableRides.length;
    if (count > prevCountRef.current && count > 0 && !currentRideRef.current) {
      playAlert();
      if ("Notification" in window && Notification.permission === "granted") {
        const latest = availableRides[0];
        if (latest) {
          try {
            new Notification("طلب مشوار جديد! 🛺", {
              body: `من: ${latest.pickup_location || "الموقع"} - إلى: ${latest.destination || "الوجهة"}`,
              icon: "/icon.png",
            });
          } catch {
            /* تجاهل */
          }
        }
      }
    }
    prevCountRef.current = count;
  }, [availableRides.length, profile, playAlert]);

  // ── طلب إذن الإشعارات ─────────────────────────────────────────
  useEffect(() => {
    if (stage === "ready" && typeof window !== "undefined" && "Notification" in window) {
      Notification.requestPermission().catch(() => {});
    }
  }, [stage]);

  // ── جلب الطلبات: «الأقرب» عبر pickup_lat/lng ──────────────────
  const fetchRides = useCallback(async () => {
    const p = profileRef.current;
    if (!p) return;

    const myCoords = coordsRef.current;
    let list: Ride[] = [];

    if (myCoords) {
      const b = radiusBounds(myCoords.lat, myCoords.lng, DEFAULT_SEARCH_RADIUS_KM);

      const inBbox = await supabase
        .from("rides")
        .select("*")
        .eq("status", "pending")
        .gte("pickup_lat", b.minLat)
        .lte("pickup_lat", b.maxLat)
        .gte("pickup_lng", b.minLng)
        .lte("pickup_lng", b.maxLng);

      // طلبات بلا إحداثيات (كتبها الراكب يدوياً) — تظهر حتى لا تضيع
      const noCoords = await supabase
        .from("rides")
        .select("*")
        .eq("status", "pending")
        .is("pickup_lat", null);

      const near = (inBbox.data || [])
        .filter(
          (r: any) =>
            typeof r.pickup_lat === "number" && typeof r.pickup_lng === "number"
        )
        .map((r: any) => ({
          ...r,
          distanceKm: haversineKm(
            myCoords.lat,
            myCoords.lng,
            r.pickup_lat as number,
            r.pickup_lng as number
          ),
        }))
        .sort((a: Ride, b: Ride) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0));

      list = [...near, ...((noCoords.data || []) as Ride[]).map((r) => ({ ...r, distanceKm: null }))];
    } else {
      const all = await supabase
        .from("rides")
        .select("*")
        .eq("status", "pending")
        .order("created_at", { ascending: false });
      list = (all.data || []) as Ride[];
    }

    // إزالة أي تكرار
    const seen = new Set<string>();
    list = list.filter((r) => {
      const k = String(r.id);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
    setAvailableRides(list);
    // مزامنة العدّاد حتى لا يصدر تنبيه عند فتح الصفحة (فقط للطلبات الجديدة فعلاً)
    prevCountRef.current = list.length;

    // «مشواري أنا» فقط — الرحلة الحالية
    if (!currentRideRef.current) {
      const { data: mineAccepted } = await supabase
        .from("rides")
        .select("*")
        .eq("status", "accepted")
        .or(`driver_id.eq.${p.id},driver_phone.eq.${p.phone}`)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (mineAccepted) {
        syncCurrentRide(mineAccepted as Ride);
        setActiveTab("current");
      }
    }
  }, [syncCurrentRide]);

  // ── 1) اشتراك realtime واحد لكل جلسة ──────────────────────────
  useEffect(() => {
    if (stage !== "ready") return;

    void fetchRides();

    const channel = supabase
      .channel("driver-rides-channel")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "rides" },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const newRide = payload.new as Ride;
            if (newRide.status === "pending") {
              setAvailableRides((prev) =>
                prev.some((r) => sameId(r.id, newRide.id))
                  ? prev
                  : [newRide, ...prev]
              );
            }
            return;
          }
          if (payload.eventType !== "UPDATE") return;
          const upd = payload.new as Ride;

          if (upd.status === "cancelled") {
            setAvailableRides((prev) => prev.filter((r) => !sameId(r.id, upd.id)));
            if (currentRideRef.current && sameId(currentRideRef.current.id, upd.id)) {
              alert("تم إلغاء المشوار ده من الراكب");
              syncCurrentRide(null);
              setActiveTab("available");
            }
            return;
          }

          if (upd.status === "pending") {
            setAvailableRides((prev) => {
              const exists = prev.some((r) => sameId(r.id, upd.id));
              return exists
                ? prev.map((r) => (sameId(r.id, upd.id) ? upd : r))
                : [upd, ...prev];
            });
            return;
          }

          if (upd.status === "accepted") {
            setAvailableRides((prev) => prev.filter((r) => !sameId(r.id, upd.id)));
            if (isMine(upd) && !currentRideRef.current) {
              syncCurrentRide(upd);
            }
            return;
          }

          if (upd.status === "completed") {
            if (currentRideRef.current && sameId(currentRideRef.current.id, upd.id)) {
              alert("تم إنهاء المشوار 🏁");
              syncCurrentRide(null);
              setActiveTab("available");
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // الاشتراك يُنشأ مرة واحدة لكل جلسة دخول
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stage, isMine, fetchRides, syncCurrentRide]);

  // ── تحديد موقع السائق (أساس فلتر الأقرب) ──────────────────────
  const locateDriver = useCallback(() => {
    if (!navigator.geolocation) {
      setGeoMsg("متصفحك لا يدعم تحديد الموقع — ستظهر كل الطلبات");
      return;
    }
    setLocating(true);
    setGeoMsg(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const c = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        coordsRef.current = c;
        setCoords(c);
        setLocating(false);
        setGeoMsg(null);
        void fetchRides();
      },
      () => {
        setLocating(false);
        coordsRef.current = null;
        setCoords(null);
        setGeoMsg("تعذر تحديد موقعك — ستظهر كل الطلبات (بدون ترتيب الأقرب)");
        void fetchRides();
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 }
    );
  }, [fetchRides]);

  // ── OTP: طلب رمز ──────────────────────────────────────────────
  const requestOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const phone = normalizeSudanesePhone(phoneDigits);
    if (!phone) {
      setAuthError("أدخل رقم هاتف سوداني صحيح (9 أرقام تبدأ بـ 9)");
      return;
    }

    setBusy(true);
    setAuthError(null);
    setAuthInfo(null);
    setPreviewCode(null);
    try {
      const res = await fetch("/api/driver/request-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setStage("code");
        setAuthInfo(data.message || "تم إرسال رمز التحقق إلى هاتفك");
        setPreviewCode(data.previewCode || null);
      } else {
        setAuthError(data.error || "تعذر إرسال الرمز — حاول مرة أخرى");
      }
    } catch {
      setAuthError("خطأ في الاتصال بالخادم");
    } finally {
      setBusy(false);
    }
  };

  // ── OTP: تحقق ودخول ───────────────────────────────────────────
  const verifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    const phone = normalizeSudanesePhone(phoneDigits);
    if (!phone || !/^\d{6}$/.test(codeDigits)) {
      setAuthError("أدخل رمز التحقق (6 أرقام)");
      return;
    }

    setBusy(true);
    setAuthError(null);
    try {
      const payload: Record<string, string> = {
        phone,
        code: codeDigits,
      };
      // بيانات اختيارية تُرسل فقط إن كُتبت (حتى لا تُمسح بيانات قديمة)
      if (nameDraft.trim()) payload.name = nameDraft.trim();
      if (bankDraft.trim()) payload.bankAccount = bankDraft.replace(/\s+/g, "");
      if (vehicleDraft.trim()) payload.vehicleType = vehicleDraft.trim();

      const res = await fetch("/api/driver/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data.ok || !data.driver) {
        setAuthError(data.error || "فشل التحقق — حاول مرة أخرى");
        return;
      }

      const p: DriverProfile = {
        id: Number(data.driver.id),
        phone: data.driver.phone,
        name: data.driver.name || "",
        bankAccount: data.driver.bankAccount || null,
        vehicleType: data.driver.vehicleType || null,
        isOnline: data.driver.isOnline !== false,
      };
      syncProfile(p);
      localStorage.setItem("driver_token", data.token);
      localStorage.setItem("driver_id", String(p.id));
      localStorage.setItem("driver_phone", p.phone);
      setIsAvailable(p.isOnline);
      setStage("ready");
      setCodeDigits("");
      locateDriver();
    } catch {
      setAuthError("خطأ في الاتصال بالخادم");
    } finally {
      setBusy(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("driver_token");
    localStorage.removeItem("driver_id");
    localStorage.removeItem("driver_phone");
    syncProfile(null);
    syncCurrentRide(null);
    setAvailableRides([]);
    setStage("login");
    setCodeDigits("");
    setAuthInfo(null);
    setPreviewCode(null);
    setEditingProfile(false);
    prevCountRef.current = 0;
  };

  // ── تحديث الملف ───────────────────────────────────────────────
  const saveProfile = async () => {
    const token = localStorage.getItem("driver_token");
    if (!token) return;
    setBusy(true);
    setAuthError(null);
    try {
      const res = await fetch("/api/driver/profile", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "x-driver-token": token,
        },
        body: JSON.stringify({
          name: nameDraft,
          bankAccount: bankDraft.replace(/\s+/g, ""),
          vehicleType: vehicleDraft,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok && data.driver) {
        syncProfile({
          id: Number(data.driver.id),
          phone: data.driver.phone,
          name: data.driver.name || "",
          bankAccount: data.driver.bankAccount || null,
          vehicleType: data.driver.vehicleType || null,
          isOnline: data.driver.isOnline !== false,
        });
        setEditingProfile(false);
        setAuthInfo("تم حفظ بياناتك ✅");
      } else {
        setAuthError(data.error || "فشل الحفظ");
      }
    } catch {
      setAuthError("خطأ في الاتصال بالخادم");
    } finally {
      setBusy(false);
    }
  };

  // ── التوفر ────────────────────────────────────────────────────
  const toggleAvailability = async () => {
    const p = profileRef.current;
    if (!p) return;
    const next = !isAvailable;
    const token = localStorage.getItem("driver_token");
    setIsAvailable(next); // متفائل
    try {
      if (token) {
        const res = await fetch("/api/driver/profile", {
          method: "PATCH",
          headers: { "Content-Type": "application/json", "x-driver-token": token },
          body: JSON.stringify({ isOnline: next }),
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok && data.driver) {
          syncProfile({ ...p, isOnline: data.driver.isOnline !== false });
          return;
        }
      }
      setIsAvailable(!next); // تراجع
      setAuthError("تعذر حفظ الحالة على الخادم");
    } catch {
      setIsAvailable(!next);
    }
  };

  // ── القبول (شرطي — يمنع القبول المزدوج) ───────────────────────
  const acceptRide = async (ride: Ride) => {
    const p = profileRef.current;
    if (!p) return;
    if (acceptingRef.current) return;
    if (currentRideRef.current) {
      alert("عندك مشوار حالي — أنهيه أولاً قبل ما تقبل طلب جديد");
      return;
    }
    if (!isAvailable) {
      alert("فعّل «متاح للطلبات 🟢» أولاً عشان تقدر تقبل مشاوير");
      return;
    }

    acceptingRef.current = true;
    try {
      const { data, error } = await supabase
        .from("rides")
        .update({
          status: "accepted",
          driver_id: p.id, // integer FK → drivers(id)
          driver_phone: p.phone,
        })
        .eq("id", ride.id)
        .eq("status", "pending")
        .select()
        .maybeSingle();

      if (error || !data) {
        setAvailableRides((prev) => prev.filter((r) => !sameId(r.id, ride.id)));
        alert("الطلب ده اتقبل من سائق تاني قبل ما تدوس — جرب طلب تاني");
        return;
      }

      syncCurrentRide(data as Ride);
      setActiveTab("current");
    } finally {
      acceptingRef.current = false;
    }
  };

  // ── إنهاء المشوار (لمشواري أنا فقط) ───────────────────────────
  const completeRide = async (rideId: string | number) => {
    const p = profileRef.current;
    if (!p || acceptingRef.current) return;

    // محاولة 1: عبر driver_id (الجديد) — محاولة 2: عبر driver_phone (رحلات قديمة)
    const attempt = async (filter: (q: any) => any) => {
      const { error } = await filter(
        supabase
          .from("rides")
          .update({ status: "completed" })
          .eq("id", rideId)
          .eq("status", "accepted")
      );
      return error;
    };

    let err =
      (await attempt((q: any) => q.eq("driver_id", p.id))) ||
      (await attempt((q: any) => q.eq("driver_phone", p.phone)));

    if (err) {
      alert("خطأ أثناء إنهاء المشوار: " + err.message);
      return;
    }
    alert("تم إنهاء المشوار 🏁");
    syncCurrentRide(null);
    setActiveTab("available");
    prevCountRef.current = 0;
    void fetchRides();
  };

  const maskedBank = profile?.bankAccount ? maskAccount(profile.bankAccount) : "—";
  const showDriver = stage === "ready" && profile;

  return (
    <div className="min-h-screen bg-[#161b22] text-slate-100 p-4 flex flex-col justify-between w-full min-w-full">
      <div className="w-full max-w-xl mx-auto flex-1 flex flex-col justify-between space-y-4">
        {/* الشريط العلوي */}
        <header className="flex justify-between items-center pt-2 pb-1">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🚖</span>
            <span className="font-extrabold text-xl text-white tracking-wide">لوحة السائق</span>
          </div>

          <button
            type="button"
            onClick={() => { window.location.href = "/"; }}
            className="bg-amber-500/10 hover:bg-amber-500/20 active:scale-95 text-amber-400 font-bold text-sm px-4 py-2.5 rounded-xl border border-amber-500/30 transition flex items-center gap-2 shadow-lg"
          >
            <span>🛺</span> الرئيسية (الراكب)
          </button>
        </header>

        {/* ══════════ شاشة الدخول برمز التحقق ══════════ */}
        {stage !== "ready" ? (
          <div className="space-y-5 py-6 flex-1 flex flex-col justify-center">
            <div className="text-center space-y-1.5">
              <h2 className="text-lg font-bold text-white">دخول السائق 🚖</h2>
              <p className="text-xs text-slate-400">
                {stage === "login"
                  ? "أدخل رقم هاتفك وسيصلك رمز تحقق (OTP) — لا مزيد من الدخول بدون تحقق"
                  : "أدخل الرمز المكوّن من 6 أرقام الذي وصل إلى هاتفك"}
              </p>
            </div>

            {stage === "login" ? (
              <form onSubmit={requestOtp} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 mb-1.5 block text-right">📞 رقم الهاتف:</label>
                  <div
                    className="flex items-stretch border border-slate-700 rounded-xl overflow-hidden bg-[#0d1117] focus-within:border-amber-500"
                    style={{ direction: 'ltr' }}
                  >
                    <div className="bg-slate-800 text-amber-400 px-3.5 py-3 text-sm font-mono font-bold border-r border-slate-700 flex items-center gap-1.5 select-none shrink-0">
                      <span>🇸🇩</span>
                      <span style={{ direction: 'ltr', unicodeBidi: 'isolate' }}>+249</span>
                    </div>
                    <input
                      type="tel"
                      required
                      inputMode="numeric"
                      maxLength={10}
                      value={phoneDigits}
                      onChange={(e) => setPhoneDigits(e.target.value.replace(/\D/g, "").slice(0, 10))}
                      placeholder="9XXXXXXXX"
                      className="w-full bg-transparent px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none font-mono text-left"
                      style={{ direction: 'ltr' }}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={busy}
                  className="w-full py-4 bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-slate-950 font-extrabold rounded-2xl text-base shadow-xl transition mt-2 disabled:opacity-50"
                >
                  {busy ? "جاري الإرسال..." : "إرسال رمز التحقق 📲"}
                </button>
              </form>
            ) : (
              <form onSubmit={verifyOtp} className="space-y-4">
                {authInfo && (
                  <p className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-3 py-2.5 leading-relaxed">
                    ✅ {authInfo}
                  </p>
                )}

                <div>
                  <label className="text-xs font-semibold text-slate-300 mb-1.5 block text-right">🔢 رمز التحقق:</label>
                  <input
                    type="text"
                    required
                    inputMode="numeric"
                    autoFocus
                    maxLength={6}
                    value={codeDigits}
                    onChange={(e) => setCodeDigits(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    placeholder="000000"
                    className="w-full bg-[#0d1117] border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono text-center tracking-[0.5em]"
                    dir="ltr"
                  />
                  {previewCode && (
                    <p className="text-[11px] text-amber-400/90 bg-amber-500/10 border border-amber-500/20 rounded-lg px-2.5 py-1.5 mt-2 leading-relaxed">
                      🧪 وضع تجريبي (بدون مزوّد إرسال): استخدم الرمز{" "}
                      <strong className="font-mono text-base tracking-widest">{previewCode}</strong>
                    </p>
                  )}
                </div>

                {/* بيانات اختيارية تُملأ مرة واحدة عند التسجيل */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 mb-1.5 block text-right">الاسم:</label>
                    <input
                      type="text"
                      value={nameDraft}
                      onChange={(e) => setNameDraft(e.target.value)}
                      placeholder="اختياري"
                      className="w-full bg-[#0d1117] border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-300 mb-1.5 block text-right">المركبة:</label>
                    <input
                      type="text"
                      value={vehicleDraft}
                      onChange={(e) => setVehicleDraft(e.target.value)}
                      placeholder="مثال: ركشة"
                      className="w-full bg-[#0d1117] border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 mb-1.5 block text-right">🏦 رقم الحساب البنكي:</label>
                  <input
                    type={showBank ? "text" : "password"}
                    value={bankDraft}
                    onChange={(e) => setBankDraft(e.target.value.replace(/\s+/g, ""))}
                    placeholder="اختياري — لتحويل المستحقات"
                    className="w-full bg-[#0d1117] border border-slate-700 rounded-xl px-3.5 py-3 text-sm text-white placeholder-slate-500 focus:outline-none font-mono text-right focus:border-amber-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={busy}
                  className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-slate-950 font-extrabold rounded-2xl text-base shadow-xl transition mt-2 disabled:opacity-50"
                >
                  {busy ? "جاري التحقق..." : "تحقق وادخل اللوحة ✅"}
                </button>

                <button
                  type="button"
                  onClick={() => { setStage("login"); setAuthInfo(null); setPreviewCode(null); setAuthError(null); }}
                  className="w-full text-center text-xs text-slate-400 hover:text-white underline transition"
                >
                  تغيير رقم الهاتف
                </button>
              </form>
            )}

            {authError && (
              <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2.5 leading-relaxed">
                ⚠️ {authError}
              </p>
            )}
          </div>
        ) : showDriver ? (
          <>
            {/* ══════════ شريط معلومات السائق (حساب مقنّع) ══════════ */}
            <div className="flex items-center justify-between bg-[#0d1117] p-3 rounded-2xl border border-slate-800 gap-2">
              <div className="text-xs text-slate-300 space-y-1 min-w-0">
                <div className="truncate">
                  {profile.name ? <span className="font-bold text-white">👤 {profile.name}</span> : null}{" "}
                  <span className="font-mono text-amber-400 font-bold" dir="ltr">+249{phoneDigits}</span>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span>🏦 الحساب:</span>
                  <span className="font-mono text-amber-400 font-bold" dir="ltr">
                    {maskedBank}
                  </span>
                  {profile.bankAccount && (
                    <button
                      type="button"
                      onClick={() => setShowBank((s) => !s)}
                      className="text-[9px] bg-slate-800 hover:bg-slate-700 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700 transition"
                    >
                      {showBank ? "إخفاء" : "إظهار"}
                    </button>
                  )}
                </div>
                {profile.vehicleType ? (
                  <div className="text-[10px] text-slate-400">🛺 {profile.vehicleType}</div>
                ) : null}
              </div>
              <div className="flex flex-col gap-1.5 shrink-0">
                <button
                  onClick={handleLogout}
                  className="text-[10px] font-bold text-red-400 hover:text-red-300 bg-red-500/10 px-2.5 py-1.5 rounded-lg border border-red-500/20 transition"
                >
                  خروج 🔒
                </button>
                <button
                  onClick={() => {
                    setEditingProfile((v) => !v);
                    setNameDraft(profile.name || "");
                    setBankDraft(profile.bankAccount || "");
                    setVehicleDraft(profile.vehicleType || "");
                    setAuthInfo(null);
                    setAuthError(null);
                  }}
                  className="text-[10px] font-bold text-slate-300 hover:text-white bg-slate-800/60 px-2.5 py-1.5 rounded-lg border border-slate-700 transition"
                >
                  تعديل البيانات ✏️
                </button>
              </div>
            </div>

            {editingProfile && (
              <div className="bg-[#0d1117] border border-slate-700 rounded-2xl p-4 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-semibold text-slate-300 mb-1 block text-right">الاسم:</label>
                    <input
                      type="text"
                      value={nameDraft}
                      onChange={(e) => setNameDraft(e.target.value)}
                      className="w-full bg-[#161b22] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-slate-300 mb-1 block text-right">المركبة:</label>
                    <input
                      type="text"
                      value={vehicleDraft}
                      onChange={(e) => setVehicleDraft(e.target.value)}
                      className="w-full bg-[#161b22] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-semibold text-slate-300 mb-1 block text-right">🏦 الحساب البنكي:</label>
                  <input
                    type="text"
                    value={bankDraft}
                    onChange={(e) => setBankDraft(e.target.value.replace(/\s+/g, ""))}
                    className="w-full bg-[#161b22] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none font-mono text-right focus:border-amber-500"
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={saveProfile}
                    disabled={busy}
                    className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs rounded-xl transition disabled:opacity-50"
                  >
                    {busy ? "جاري الحفظ..." : "حفظ ✅"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingProfile(false)}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            )}

            {/* حالة التواجد + الموقع */}
            <div className="space-y-2">
              <div className="flex justify-between items-center bg-[#0d1117] p-3 rounded-2xl border border-slate-800">
                <span className="text-sm font-semibold text-slate-300">حالة التواجد:</span>
                <button
                  onClick={toggleAvailability}
                  className={`text-xs px-4 py-2 rounded-xl font-extrabold transition flex items-center gap-2 ${
                    isAvailable
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                      : "bg-red-500/10 text-red-400 border border-red-500/30"
                  }`}
                >
                  <span className={`w-2.5 h-2.5 rounded-full ${isAvailable ? "bg-emerald-400" : "bg-red-400"}`}></span>
                  {isAvailable ? "متاح للطلبات 🟢" : "مشغول / استراحة 🔴"}
                </button>
              </div>

              <div className="flex items-center justify-between bg-[#0d1117] p-3 rounded-2xl border border-slate-800">
                <span className="text-xs text-slate-300">
                  {coords
                    ? `📍 موقعك مفعّل — نعرض الطلبات الأقرب خلال ${DEFAULT_SEARCH_RADIUS_KM} كم`
                    : geoMsg || "📍 حدد موقعك لعرض الطلبات الأقرب"}
                </span>
                <button
                  type="button"
                  onClick={locateDriver}
                  disabled={locating}
                  className="text-[10px] bg-slate-800 hover:bg-slate-700 text-amber-400 px-2.5 py-1.5 rounded-lg border border-slate-700 font-bold transition disabled:opacity-50"
                >
                  {locating ? "..." : "تحديث موقعي"}
                </button>
              </div>
            </div>

            {/* الخريطة */}
            <div className="w-full h-44 rounded-2xl overflow-hidden border border-slate-700/60 shadow-xl shrink-0">
              <Map pickupName={currentRide ? currentRide.pickup_location : "موقعي الحالي"} />
            </div>

            {/* التبويبات */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setActiveTab("available")}
                className={`py-3 text-xs font-extrabold rounded-xl border transition ${
                  activeTab === "available"
                    ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md"
                    : "bg-[#0d1117] text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                الطلبات المتاحة 🔔 ({availableRides.length})
              </button>
              <button
                onClick={() => setActiveTab("current")}
                className={`py-3 text-xs font-extrabold rounded-xl border transition ${
                  activeTab === "current"
                    ? "bg-amber-500 text-slate-950 border-amber-500 shadow-md"
                    : "bg-[#0d1117] text-slate-400 border-slate-800 hover:text-white"
                }`}
              >
                المشوار الحالي 🚖 {currentRide ? "(1)" : "(0)"}
              </button>
            </div>

            {/* المحتوى */}
            {activeTab === "available" ? (
              <div className="space-y-3 flex-1">
                {!isAvailable ? (
                  <div className="text-center py-8 bg-[#0d1117] border border-slate-800 rounded-2xl text-slate-500 text-xs font-medium">
                    أنت في وضع «مشغول / استراحة 🔴» — الطلبات الجديدة لن تُقبل منك.
                  </div>
                ) : availableRides.length === 0 ? (
                  <div className="text-center py-8 bg-[#0d1117] border border-slate-800 rounded-2xl text-slate-500 text-xs font-medium">
                    لا توجد طلبات قريبة حالياً. انتظر قليلاً... ⏳
                  </div>
                ) : (
                  availableRides.map((ride) => (
                    <div key={ride.id} className="bg-[#0d1117] border border-slate-700/80 rounded-2xl p-4 space-y-3 shadow-lg">
                      <div className="flex justify-between items-center text-xs border-b border-slate-800 pb-2.5">
                        <span className="font-bold text-white text-sm">👤 {ride.passenger_name}</span>
                        <div className="flex items-center gap-1.5">
                          {ride.distanceKm !== null && ride.distanceKm !== undefined ? (
                            <span className="bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-lg border border-emerald-500/20 font-bold text-[10px]">
                              📍 {formatKm(ride.distanceKm)}
                            </span>
                          ) : null}
                          <span className="bg-amber-500/10 text-amber-400 px-2.5 py-1 rounded-lg border border-amber-500/20 font-bold">
                            {serviceTypeLabel(ride.service_type)}
                          </span>
                        </div>
                      </div>
                      <div className="text-xs space-y-1.5 text-slate-300">
                        <div>📍 من: <span className="text-white font-semibold">{ride.pickup_location}</span></div>
                        <div>🏁 إلى: <span className="text-white font-semibold">{ride.destination}</span></div>
                        {ride.offered_price ? (
                          <div className="text-amber-400 font-bold font-mono text-sm">
                            💰 السعر المقترح: <span style={{ direction: "ltr", display: "inline-block" }}>{formatPrice(ride.offered_price)} ج.س</span>
                          </div>
                        ) : null}
                        <div className="text-slate-400 flex items-center justify-between pt-1">
                          <span>📞 الهاتف:</span>
                          <a
                            href={`tel:${ride.phone_number}`}
                            className="font-mono text-amber-400 hover:underline font-bold text-sm"
                            style={{ direction: "ltr" }}
                          >
                            {ride.phone_number}
                          </a>
                        </div>
                      </div>
                      <button
                        onClick={() => acceptRide(ride)}
                        disabled={!!currentRide || acceptingRef.current}
                        className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg transition disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        {currentRide ? "عندك مشوار حالي أولاً" : "قبول المشوار ✅"}
                      </button>
                    </div>
                  ))
                )}
              </div>
            ) : (
              <div className="space-y-3 flex-1">
                {!currentRide ? (
                  <div className="text-center py-8 bg-[#0d1117] border border-slate-800 rounded-2xl text-slate-500 text-xs font-medium">
                    لا توجد رحلة حالية قيد التنفيذ.
                  </div>
                ) : (
                  <div className="bg-[#0d1117] border border-slate-700/80 rounded-2xl p-4 space-y-3.5 shadow-lg">
                    <div className="flex justify-between items-center text-xs border-b border-slate-800 pb-2.5">
                      <span className="font-bold text-emerald-400 text-sm">🟢 مشوار جاري (مشواري أنا)</span>
                      <span className="font-bold text-white text-sm">👤 {currentRide.passenger_name}</span>
                    </div>
                    <div className="text-xs space-y-1.5 text-slate-300">
                      <div>📍 من: <span className="text-white font-semibold">{currentRide.pickup_location}</span></div>
                      <div>🏁 إلى: <span className="text-white font-semibold">{currentRide.destination}</span></div>
                      {currentRide.offered_price ? (
                        <div className="text-amber-400 font-bold font-mono text-sm">
                          💰 السعر المقترح: <span style={{ direction: "ltr", display: "inline-block" }}>{formatPrice(currentRide.offered_price)} ج.س</span>
                        </div>
                      ) : null}
                      <div className="text-slate-400 flex items-center justify-between pt-1">
                        <span>📞 الهاتف:</span>
                        <a
                          href={`tel:${currentRide.phone_number}`}
                          className="font-mono text-amber-400 hover:underline font-bold text-sm"
                          style={{ direction: "ltr" }}
                        >
                          {currentRide.phone_number}
                        </a>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <a
                        href={`tel:${currentRide.phone_number}`}
                        className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-center text-xs font-bold rounded-xl border border-slate-700 transition"
                      >
                        اتصال بالزبون 📞
                      </a>
                      <a
                        href={`https://wa.me/${currentRide.phone_number.replace("+", "")}`}
                        target="_blank"
                        rel="noreferrer"
                        className="py-2.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 text-center text-xs font-bold rounded-xl border border-emerald-500/30 transition"
                      >
                        واتساب 💬
                      </a>
                    </div>

                    <button
                      onClick={() => completeRide(currentRide.id)}
                      disabled={acceptingRef.current}
                      className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg transition disabled:opacity-50"
                    >
                      إكمال / إنهاء المشوار 🏁
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        ) : null}
      </div>
    </div>
  );
}
